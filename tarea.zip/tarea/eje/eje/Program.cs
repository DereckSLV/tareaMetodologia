﻿using System;

namespace ejer3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;

            // Solicitar al usuario que ingrese un número
            Console.WriteLine("Ingrese un número: ");
            num = int.Parse(Console.ReadLine());

            Console.WriteLine($"Múltiplos de 5 entre 1 y {num}:");

            // Ciclo for para recorrer los números desde 1 hasta el número ingresado
            for (int i = 1; i <= num; i++)
            {
                // Verificar si el número es múltiplo de 5
                if (i % 5 == 0)
                {
                    Console.WriteLine(i);
                }
            }

            Console.ReadKey();
        }
    }
}
