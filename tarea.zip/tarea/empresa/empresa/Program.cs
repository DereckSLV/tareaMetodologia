﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace empresa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int nVende = 0, sal = 200;
            int cont1 = 0, cont2 = 0, cont3 = 0, cont4 = 0, cont5 = 0;
            int cont6 = 0, cont7 = 0,  cont8 = 0, cont9 = 0;

            Console.WriteLine("Programa que calcula las ganancias netas de trabajadores " +
                              "en base a comisiones");

            do
            {
                // SOLICITANDO EL TAMANIO DEL ARREGLO
                Console.Write("Digite la cantidad de vendedores: ");

                // Intentamos convertir la entrada a un número
                if (!int.TryParse(Console.ReadLine(), out nVende) || nVende <= 0)
                {
                    Console.WriteLine("ERROR: Ingrese un número válido mayor a 0.");
                    Console.ReadKey();
                    Console.Clear();
                }

            } while (nVende <= 0);


            int[] sales = new int[nVende];

            for(int i = 0; i < nVende; i++)
            {
                double comisiones = 0;

                Console.Clear();

                // SOLICITANDO VENTAS DE CADA VENDEDOR
                Console.Write("Digite las ventas de la semana\n" +
                                  "del vendedor #{0}: ", i + 1);
                comisiones = int.Parse(Console.ReadLine());

                // CALCULANDO LAS COMISIONES
                comisiones = comisiones * 0.09;

                // REGISTRANDO GANANCIAS NETAS DE VENDEDOR
                sales[i] = (int)comisiones + sal;

                // VERIFICANDO RANGOS DE GANANCIAS
                if (sales[i] >= 200 && sales[i] <300)
                {
                    cont1++;
                }
                if (sales[i] >= 300 && sales[i] < 400)
                {
                    cont2++;
                }
                if (sales[i] >= 400 && sales[i] < 500)
                {
                    cont3++;
                }
                if (sales[i] >= 500 && sales[i] < 600)
                {
                    cont4++;
                }
                if (sales[i] >= 600 && sales[i] < 700)
                {
                    cont5++;
                }
                if (sales[i] >= 700 && sales[i] < 800)
                {
                    cont6++;
                }
                if (sales[i] >= 800 && sales[i] < 900)
                {
                    cont7++;
                }
                if (sales[i] >= 900 && sales[i] < 1000)
                {
                    cont8++;
                }
                if (sales[i] >= 1000)
                {
                    cont9++;
                }
            }

            Console.WriteLine("Rangos de ganancias");

            Console.Write("1. {0} vendedores\n" +
                          "2. {1} vendedores\n" +
                          "3. {2} vendedores\n" +
                          "4. {3} vendedores\n" +
                          "5. {4} vendedores\n" +
                          "6. {5} vendedores\n" +
                          "7. {6} vendedores\n" +
                          "8. {7} vendedores\n" +
                          "9. {8} vendedores\n",
                          cont1, cont2, cont3,
                          cont4, cont5, cont6,
                          cont7, cont8, cont9);

            Console.ReadKey();
        }
    }
}
