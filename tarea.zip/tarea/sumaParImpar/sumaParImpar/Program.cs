﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*Escriba un programa que calcule la suma de todos los números pares entre 1 y un número
ingresado por el usuario. Utilice un ciclo for para iterar sobre los números y una estructura
if para verificar si cada número es par.*/

namespace ejer1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, suma = 0;

            Console.Write("Digite un numero: ");
            num = int.Parse(Console.ReadLine());

            Console.WriteLine("Numeros pares: ");
            for (int i = 1; i < num; i++)
            {
                if (i % 2 == 0)
                {
                    Console.Write("{0}-", i);
                    suma += i;
                }

            }

            Console.WriteLine("\nLa suma total de numeros par es: {0}", suma);

            Console.ReadKey();
        }
    }
}
