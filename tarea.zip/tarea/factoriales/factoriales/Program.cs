﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*. Escriba un programa que calcule el factorial de un número ingresado por el usuario
utilizando un ciclo while. Use una estructura if para manejar el caso en que el número
ingresado es negativo, ya que el factorial no está definido para números negativos.*/

namespace ejer2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num, facto = 1;

            Console.Write("Digite un numero: ");
            num = int.Parse(Console.ReadLine());
            if (num > 0)
            {
                int i = 1;
                while (i <= num)
                {
                    facto = facto * i;

                    i++;
                }

                Console.WriteLine("El factorial de {0} es: {1}", num, facto);
            }
            else
            {
                Console.WriteLine("NO SE PERMITEN NUMEROS NEGATIVOS NI IGUALES A 0");
            }

            Console.ReadKey();
        }
    }
}
